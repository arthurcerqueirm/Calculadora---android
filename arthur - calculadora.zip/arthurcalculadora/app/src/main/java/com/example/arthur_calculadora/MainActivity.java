package com.example.arthur_calculadora;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private Button BtnSoma, BtnMulti, BtnDivi, BtnSubt,BtnCalcula;
    private EditText edtNum;
    private String Acao;
    private Double valor;

    private void initComponents(){
        BtnSoma = findViewById(R.id.btnSoma);
        BtnMulti = findViewById(R.id.btnMultiplicacao);
        BtnDivi = findViewById(R.id.btnDivisao);
        BtnSubt = findViewById(R.id.btnSubtracao);
        edtNum = findViewById(R.id.edtNumero);
        BtnCalcula = findViewById(R.id.btnCalcula);
    }

    private void initActivites(){

        BtnSoma.setOnClickListener(v ->{
            Acao = "Soma";
            valor = Double.parseDouble(edtNum.getText().toString());
            edtNum.setText(0);
        });
        BtnMulti.setOnClickListener(v ->{

        });
        BtnDivi.setOnClickListener(v ->{

        });
        BtnSubt.setOnClickListener(v ->{

        });
        BtnCalcula.setOnClickListener(v ->{
            switch (Acao){
                case "Soma":{
                    valor = valor + Double.parseDouble(edtNum.getText().toString());
                    edtNum.setText(valor.toString());
                }
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}